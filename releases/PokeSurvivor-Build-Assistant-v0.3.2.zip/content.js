(() => {
  "use strict";

  if (!document.querySelector("#game") || !document.querySelector("#scr-levelup") || !document.querySelector("#cards")) return;

  const STATE_KEY = "psba_player_state_v1";
  const MAX_MOVE_SLOTS = 4;
  const MAX_MOVES_WITH_BONDS = 16;
  const AUTO_PICK_MIN_SCORE = 6;
  const AUTO_PICK_DELAY_MS = 750;
  const EVO_STATS = ["Power", "Vigor", "Reflexes", "Armor", "Synthesis", "Magnet", "Sprint"];
  const STRATEGIES = {
    balanced: "Cân bằng",
    evolve: "Ưu tiên tiến hóa",
    physical: "Thiên vật lý",
    special: "Thiên đặc biệt",
    survival: "Sinh tồn"
  };

  const state = {
    pokemon: "",
    manualPokemon: false,
    strategy: "balanced",
    autoPick: true,
    targets: [],
    learnedMoves: [],
    fusedGroups: [],
    statPicks: [],
    lastLevel: 0
  };
  let pokemonData = [];
  let moveData = [];
  let lastAutoName = "";
  let isLevelUpVisible = false;
  let wasGameOver = false;
  let panelOpen = false;
  let cachedCandidates = [];
  let autoPickTimer = null;
  let autoPickSignature = "";
  let pendingAutoPickSignature = "";
  let lastTrackedSelectionSignature = "";
  let lastTrackedSelectionAt = 0;

  const host = document.createElement("div");
  host.id = "psba-host";
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <button id="psba-fab" class="fab" type="button" aria-label="Mở trợ lý build">PS</button>
    <aside id="psba-panel" class="panel" aria-label="PokéSurvivor Build Assistant">
      <header class="header">
        <div><div class="eyebrow">POKÉ SURVIVOR</div><strong>Build Assistant</strong></div>
        <button id="psba-minimize" class="icon-button" type="button" aria-label="Thu gọn">−</button>
      </header>
      <div class="body">
        <p id="psba-status" class="status">Đang đọc dữ liệu game…</p>
        <label for="psba-pokemon">Pokémon đang chơi</label>
        <div class="pokemon-row">
          <input id="psba-pokemon" list="psba-pokemon-list" placeholder="Ví dụ: Pikachu" autocomplete="off">
          <button id="psba-sync" class="quiet-button" type="button" title="Đọc Pokémon đang hiển thị ở menu game">Đồng bộ</button>
        </div>
        <datalist id="psba-pokemon-list"></datalist>
        <div id="psba-types" class="types"><span class="muted">Chưa nhận diện hệ</span></div>

        <label for="psba-strategy">Hướng build</label>
        <select id="psba-strategy">
          <option value="balanced">Cân bằng</option>
          <option value="evolve">Ưu tiên tiến hóa</option>
          <option value="physical">Thiên vật lý</option>
          <option value="special">Thiên đặc biệt</option>
          <option value="survival">Sinh tồn</option>
        </select>

        <div class="section-title"><span>Skill muốn nhắm tới</span><small>tùy chọn</small></div>
        <div class="target-row">
          <input id="psba-target-input" list="psba-move-list" placeholder="Tìm move để ưu tiên" autocomplete="off">
          <button id="psba-add-target" class="quiet-button" type="button">+</button>
        </div>
        <datalist id="psba-move-list"></datalist>
        <div id="psba-targets" class="chips empty">Chưa chọn skill mục tiêu.</div>

        <div class="section-title"><span>Đề xuất ở lần lên cấp này</span><small id="psba-level">chờ thẻ</small></div>
        <div id="psba-recommendations" class="recommendations"><p class="muted">Khi màn hình chọn thẻ xuất hiện, gợi ý sẽ hiện ở đây.</p></div>
        <label class="auto-pick-row"><span><input id="psba-auto-pick" type="checkbox"> Tự chọn thẻ dẫn điểm</span></label>
        <p id="psba-auto-status" class="muted auto-status">Tự chọn khi thẻ trên 6 điểm và đứng đầu; chờ thẻ mở khóa.</p>

        <div class="section-title"><span>Skill đã học trong lượt</span><button id="psba-reset" class="text-button" type="button">Xóa lượt</button></div>
        <div id="psba-build" class="build-list"><p class="muted">Chưa ghi nhận lựa chọn nào.</p></div>
        <div class="owned-row">
          <input id="psba-known-move" list="psba-move-list" placeholder="Ghi nhận move khởi đầu / đã có" autocomplete="off">
          <input id="psba-known-level" class="known-level-input" type="number" min="1" max="5" value="1" aria-label="Cấp skill đã có">
          <button id="psba-add-known" class="quiet-button" type="button">Thêm</button>
        </div>
        <div class="section-title"><span>Gợi ý ghép Bond</span><small id="psba-bond-count">cần 2 skill</small></div>
        <div id="psba-fusions" class="recommendations"><p class="muted">Học thêm skill để xem các cặp kết hợp.</p></div>
        <p class="footnote">Extension tự ghi nhận thẻ bạn chọn. Tự chọn có thể tắt bất cứ lúc nào; gợi ý Bond là đánh giá chiến thuật, không phải công thức đặc biệt của game.</p>
      </div>
    </aside>`;
  document.documentElement.appendChild(host);

  const ui = {
    panel: shadow.querySelector("#psba-panel"),
    fab: shadow.querySelector("#psba-fab"),
    status: shadow.querySelector("#psba-status"),
    pokemon: shadow.querySelector("#psba-pokemon"),
    pokemonList: shadow.querySelector("#psba-pokemon-list"),
    types: shadow.querySelector("#psba-types"),
    strategy: shadow.querySelector("#psba-strategy"),
    autoPick: shadow.querySelector("#psba-auto-pick"),
    autoStatus: shadow.querySelector("#psba-auto-status"),
    targetInput: shadow.querySelector("#psba-target-input"),
    knownMove: shadow.querySelector("#psba-known-move"),
    knownLevel: shadow.querySelector("#psba-known-level"),
    moveList: shadow.querySelector("#psba-move-list"),
    targets: shadow.querySelector("#psba-targets"),
    level: shadow.querySelector("#psba-level"),
    recommendations: shadow.querySelector("#psba-recommendations"),
    build: shadow.querySelector("#psba-build"),
    fusions: shadow.querySelector("#psba-fusions"),
    bondCount: shadow.querySelector("#psba-bond-count")
  };

  shadow.querySelector("#psba-minimize").addEventListener("click", () => setPanelOpen(false));
  ui.fab.addEventListener("click", () => setPanelOpen(true));
  ui.pokemon.addEventListener("change", onPokemonInput);
  ui.pokemon.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      onPokemonInput();
      ui.pokemon.blur();
    }
  });
  shadow.querySelector("#psba-sync").addEventListener("click", syncPartnerFromGame);
  ui.strategy.addEventListener("change", () => {
    state.strategy = ui.strategy.value;
    persistState();
    refreshRecommendations();
  });
  ui.autoPick.addEventListener("change", () => {
    state.autoPick = ui.autoPick.checked;
    persistState();
    refreshRecommendations();
  });
  shadow.querySelector("#psba-add-target").addEventListener("click", addTarget);
  shadow.querySelector("#psba-add-known").addEventListener("click", addKnownMove);
  ui.knownMove.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      addKnownMove();
    }
  });
  ui.targetInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      addTarget();
    }
  });
  shadow.querySelector("#psba-reset").addEventListener("click", resetRun);
  ui.autoPick.checked = state.autoPick;

  const cardsRoot = document.querySelector("#cards");
  cardsRoot.addEventListener("click", onGameCardClick, true);
  document.addEventListener("keydown", onGameLevelUpKeydown, true);
  const observer = new MutationObserver(() => {
    observePartnerName();
    updateLevelUpState();
    updateGameOverState();
  });
  for (const selector of ["#cards", "#scr-levelup", "#scr-over", "#menu-partner-name", "#res-name", "#starter-info"]) {
    const element = document.querySelector(selector);
    if (element) observer.observe(element, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ["class", "data-id", "data-move"] });
  }

  setPanelOpen(false);
  loadStoredState();
  loadReferenceData();
  observePartnerName();
  updateLevelUpState();
  updateGameOverState();

  function normalize(value) {
    return String(value || "")
      .replace(/♀/g, " female")
      .replace(/♂/g, " male")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, " ")
      .trim()
      .replace(/\s+/g, " ");
  }

  function stateCopy() {
    return {
      pokemon: state.pokemon,
      manualPokemon: state.manualPokemon,
      strategy: state.strategy,
      autoPick: state.autoPick,
      targets: [...state.targets],
      learnedMoves: state.learnedMoves.map((move) => ({ ...move })),
      fusedGroups: state.fusedGroups.map((group) => [...group]),
      statPicks: [...state.statPicks],
      lastLevel: state.lastLevel
    };
  }

  async function loadStoredState() {
    try {
      const saved = await chrome.storage.local.get(STATE_KEY);
      const value = saved[STATE_KEY];
      if (value && typeof value === "object") {
        state.pokemon = String(value.pokemon || "");
        state.manualPokemon = Boolean(value.manualPokemon);
        state.strategy = Object.prototype.hasOwnProperty.call(STRATEGIES, value.strategy) ? value.strategy : "balanced";
        state.autoPick = value.autoPick === undefined ? true : Boolean(value.autoPick);
        state.targets = Array.isArray(value.targets) ? value.targets.filter((item) => typeof item === "string") : [];
        state.learnedMoves = Array.isArray(value.learnedMoves) ? value.learnedMoves.filter((item) => item && typeof item.name === "string").slice(0, MAX_MOVES_WITH_BONDS) : [];
        state.fusedGroups = Array.isArray(value.fusedGroups)
          ? value.fusedGroups.map((group) => Array.isArray(group) ? group.filter((name) => typeof name === "string").slice(0, MAX_MOVE_SLOTS) : []).filter((group) => group.length >= 2).slice(0, MAX_MOVE_SLOTS)
          : [];
        state.statPicks = Array.isArray(value.statPicks) ? value.statPicks.filter((item) => typeof item === "string").slice(-12) : [];
        state.lastLevel = Number.isFinite(Number(value.lastLevel)) ? Number(value.lastLevel) : 0;
      }
      syncUiFromState();
    } catch (_error) {
      ui.status.textContent = "Không đọc được cài đặt đã lưu; trợ lý vẫn hoạt động trong phiên này.";
    }
  }

  function persistState() {
    chrome.storage.local.set({ [STATE_KEY]: stateCopy() }).catch(() => {});
  }

  async function loadReferenceData() {
    ui.status.textContent = "Đang tải Pokédex và bảng move chính thức…";
    try {
      const response = await chrome.runtime.sendMessage({ type: "psba:get-reference-html" });
      if (!response || response.error) throw new Error(response?.error || "Không lấy được dữ liệu tham khảo.");
      const parsed = parseReferencePages(response);
      pokemonData = parsed.pokemon;
      moveData = parsed.moves;
      populateLists();
      syncUiFromState();
      observePartnerName();
      ui.status.textContent = `Đã nạp ${pokemonData.length} Pokémon và ${moveData.length} move từ trang chính thức.`;
      refreshRecommendations();
    } catch (_error) {
      ui.status.textContent = "Không tải được dữ liệu tham khảo. Có thể nhập Pokémon và vẫn xem được gợi ý cơ bản.";
      refreshRecommendations();
    }
  }

  function parseReferencePages(reference) {
    const parser = new DOMParser();
    const dexDocument = parser.parseFromString(reference.pokedex, "text/html");
    const movesDocument = parser.parseFromString(reference.moves, "text/html");
    const pokemon = Array.from(dexDocument.querySelectorAll('li[id^="p"]'))
      .filter((item) => /^p\d+$/.test(item.id))
      .map((item) => ({
        id: Number(item.id.slice(1)),
        name: item.querySelector(".nm")?.textContent.trim() || item.querySelector("img[alt]")?.alt || "",
        types: Array.from(item.querySelectorAll(".tys .ty"), (type) => type.textContent.trim()).filter(Boolean)
      }))
      .filter((item) => item.name);
    const moves = Array.from(movesDocument.querySelectorAll("table tbody tr"))
      .map((row) => {
        const cells = Array.from(row.cells);
        const evolutionText = cells[5]?.innerText.trim() || "";
        const evoStat = evolutionText.match(/with\s+([A-Za-z]+)/i)?.[1] || "";
        return {
          name: cells[0]?.innerText.trim() || "",
          type: cells[1]?.innerText.trim() || "",
          category: cells[2]?.innerText.trim() || "",
          kind: cells[3]?.innerText.trim() || "",
          description: cells[4]?.innerText.trim() || "",
          evolutionText,
          evoStat: EVO_STATS.find((stat) => normalize(stat) === normalize(evoStat)) || ""
        };
      })
      .filter((item) => item.name);
    return { pokemon, moves };
  }

  function populateLists() {
    ui.pokemonList.replaceChildren();
    ui.moveList.replaceChildren();
    const pokemonFragment = document.createDocumentFragment();
    for (const pokemon of pokemonData) {
      const option = document.createElement("option");
      option.value = pokemon.name;
      pokemonFragment.append(option);
    }
    ui.pokemonList.append(pokemonFragment);
    const moveFragment = document.createDocumentFragment();
    for (const move of moveData) {
      const option = document.createElement("option");
      option.value = move.name;
      moveFragment.append(option);
    }
    ui.moveList.append(moveFragment);
  }

  function syncUiFromState() {
    ui.pokemon.value = state.pokemon;
    ui.strategy.value = state.strategy;
    ui.autoPick.checked = state.autoPick;
    renderTypes();
    renderTargets();
    renderBuild();
  }

  function currentPokemon() {
    const key = normalize(state.pokemon);
    return pokemonData.find((pokemon) => normalize(pokemon.name) === key) || null;
  }

  function onPokemonInput() {
    const nextPokemon = ui.pokemon.value.trim();
    if (state.pokemon && normalize(state.pokemon) !== normalize(nextPokemon)) clearRunTracker();
    state.pokemon = nextPokemon;
    state.manualPokemon = true;
    persistState();
    renderTypes();
    refreshRecommendations();
  }

  function observePartnerName() {
    if (!pokemonData.length) return;
    const candidates = ["#menu-partner-name", "#res-name", "#starter-info"];
    for (const selector of candidates) {
      const text = document.querySelector(selector)?.textContent?.trim();
      if (!text) continue;
      const match = findPokemonInText(text);
      if (!match || match.name === lastAutoName) continue;
      if (lastAutoName && normalize(match.name) !== normalize(lastAutoName)) clearRunTracker();
      lastAutoName = match.name;
      if (!state.manualPokemon || !state.pokemon) {
        state.pokemon = match.name;
        state.manualPokemon = false;
        persistState();
        syncUiFromState();
        refreshRecommendations();
      }
      return;
    }
  }

  function findPokemonInText(text) {
    const normalizedText = ` ${normalize(text)} `;
    const matches = pokemonData
      .filter((pokemon) => pokemon.name && normalizedText.includes(` ${normalize(pokemon.name)} `))
      .sort((a, b) => normalize(b.name).length - normalize(a.name).length);
    return matches[0] || null;
  }

  function syncPartnerFromGame() {
    const selectors = ["#menu-partner-name", "#res-name", "#starter-info"];
    for (const selector of selectors) {
      const text = document.querySelector(selector)?.textContent?.trim();
      const match = text && findPokemonInText(text);
      if (!match) continue;
      if (state.pokemon && normalize(state.pokemon) !== normalize(match.name)) clearRunTracker();
      state.pokemon = match.name;
      state.manualPokemon = false;
      lastAutoName = match.name;
      persistState();
      syncUiFromState();
      refreshRecommendations();
      return;
    }
    ui.status.textContent = "Chưa đọc được tên Pokémon trong menu game. Hãy chọn hoặc nhập tên ở ô trên.";
  }

  function renderTypes() {
    const pokemon = currentPokemon();
    ui.types.replaceChildren();
    if (!pokemon?.types.length) {
      const label = document.createElement("span");
      label.className = "muted";
      label.textContent = state.pokemon ? "Chưa có hệ trong dữ liệu tham khảo." : "Chưa nhận diện hệ";
      ui.types.append(label);
      return;
    }
    for (const type of pokemon.types) {
      const pill = document.createElement("span");
      pill.className = "type-pill";
      pill.textContent = type;
      ui.types.append(pill);
    }
  }

  function addTarget() {
    const typed = ui.targetInput.value.trim();
    if (!typed) return;
    const exact = moveData.find((move) => normalize(move.name) === normalize(typed));
    const value = exact?.name || typed;
    if (!state.targets.some((item) => normalize(item) === normalize(value))) state.targets.push(value);
    ui.targetInput.value = "";
    persistState();
    renderTargets();
    refreshRecommendations();
  }

  function addKnownMove() {
    const typed = ui.knownMove.value.trim();
    const exact = moveData.find((move) => normalize(move.name) === normalize(typed));
    if (!exact) {
      ui.status.textContent = "Chọn move trong danh sách chính thức để ghi nhận chính xác.";
      return;
    }
    const level = Math.max(1, Math.min(5, Number(ui.knownLevel.value) || 1));
    ui.knownLevel.value = String(level);
    const existing = state.learnedMoves.find((move) => normalize(move.name) === normalize(exact.name));
    if (existing) existing.level = level;
    else if (state.learnedMoves.length < MAX_MOVES_WITH_BONDS) state.learnedMoves.push({ name: exact.name, level, evolved: false });
    else {
      ui.status.textContent = "Đã đủ 16 skill được theo dõi trong lượt này.";
      return;
    }
    ui.knownMove.value = "";
    persistState();
    renderBuild();
    refreshRecommendations();
  }

  function renderTargets() {
    ui.targets.replaceChildren();
    if (!state.targets.length) {
      ui.targets.classList.add("empty");
      ui.targets.textContent = "Chưa chọn skill mục tiêu.";
      return;
    }
    ui.targets.classList.remove("empty");
    for (const target of state.targets) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "chip";
      chip.textContent = `${target} ×`;
      chip.title = "Bỏ skill mục tiêu";
      chip.addEventListener("click", () => {
        state.targets = state.targets.filter((item) => normalize(item) !== normalize(target));
        persistState();
        renderTargets();
        refreshRecommendations();
      });
      ui.targets.append(chip);
    }
  }

  function resetRun() {
    clearRunTracker();
    persistState();
    refreshRecommendations();
  }

  function clearRunTracker() {
    if (autoPickTimer) clearTimeout(autoPickTimer);
    autoPickTimer = null;
    pendingAutoPickSignature = "";
    autoPickSignature = "";
    lastTrackedSelectionSignature = "";
    lastTrackedSelectionAt = 0;
    state.learnedMoves = [];
    state.fusedGroups = [];
    state.statPicks = [];
    state.lastLevel = 0;
    renderBuild();
  }

  function updateLevelUpState() {
    const screen = document.querySelector("#scr-levelup");
    const visible = Boolean(screen && !screen.classList.contains("hidden") && getComputedStyle(screen).display !== "none");
    if (visible !== isLevelUpVisible) {
      const wasVisible = isLevelUpVisible;
      isLevelUpVisible = visible;
      if (visible) setPanelOpen(true);
      else if (wasVisible) {
        setPanelOpen(false);
        autoPickSignature = "";
        if (autoPickTimer) clearTimeout(autoPickTimer);
        autoPickTimer = null;
        pendingAutoPickSignature = "";
        ui.autoStatus.textContent = "Đang chờ lần lên cấp tiếp theo.";
      }
    }
    if (visible) {
      const level = Number(document.querySelector("#lvl-num")?.textContent?.trim());
      if (level > 0 && state.lastLevel > 2 && level <= 2) clearRunTracker();
      if (level > 0 && level !== state.lastLevel) {
        state.lastLevel = level;
        persistState();
      }
      refreshRecommendations();
    }
  }

  function updateGameOverState() {
    const screen = document.querySelector("#scr-over");
    const visible = Boolean(screen && !screen.classList.contains("hidden") && getComputedStyle(screen).display !== "none");
    if (visible && !wasGameOver) {
      wasGameOver = true;
      clearRunTracker();
      persistState();
      ui.status.textContent = "Pokémon đã bị hạ — build của lượt này đã được reset.";
      setPanelOpen(false);
    } else if (!visible) {
      wasGameOver = false;
    }
  }

  function cardNodes() {
    const cardClassNodes = Array.from(cardsRoot.querySelectorAll(".card"));
    if (cardClassNodes.length >= 2) return cardClassNodes;
    const buttons = Array.from(cardsRoot.querySelectorAll('button, [role="button"]'));
    if (buttons.length >= 2) return buttons;
    return Array.from(cardsRoot.children).filter((node) => node instanceof HTMLElement);
  }

  function candidateFromCard(card) {
    const parts = [card.innerText || card.textContent || ""];
    const attributes = [];
    for (const element of [card, ...card.querySelectorAll("[data-id], [data-move], [data-type], [title], [aria-label]")]) {
      for (const attribute of ["data-id", "data-move", "data-type", "title", "aria-label"]) {
        const value = element.getAttribute?.(attribute);
        if (value) attributes.push(value);
      }
    }
    const classes = [card.className, ...Array.from(card.querySelectorAll("[class]"), (node) => node.className)]
      .filter((value) => typeof value === "string")
      .join(" ")
      .toLowerCase();
    const fullText = `${parts.join(" ")} ${attributes.join(" ")}`;
    const normalizedText = normalize(fullText);
    const move = moveData
      .filter((item) => normalizedText.includes(normalize(item.name)))
      .sort((a, b) => normalize(b.name).length - normalize(a.name).length)[0] || null;
    const evolution = /evol|golden|gold card|evolved/.test(normalizedText) || /\bevo\b|evolution|golden/.test(classes);
    const stat = move ? "" : EVO_STATS.find((item) => normalizedText.includes(normalize(item))) || "";
    return { element: card, text: (card.innerText || card.textContent || "").trim().replace(/\s+/g, " "), normalizedText, move, evolution, stat };
  }

  function moveProfile(move) {
    const description = normalize(move?.description);
    const kind = normalize(move?.kind);
    const category = normalize(move?.category);
    const statuses = [];
    if (/burn|burns|burned/.test(description)) statuses.push("burn");
    if (/poison|poisons|poisoned|toxic/.test(description)) statuses.push("poison");
    if (/slow|slows|slowed/.test(description)) statuses.push("slow");
    if (/freeze|freezes|frozen/.test(description)) statuses.push("freeze");
    if (/stun|stuns|paraly/.test(description)) statuses.push("stun");
    return {
      category: category === "physical" ? "Physical" : category === "special" ? "Special" : "",
      isBuff: kind === "buff" || /deals no damage|builds/.test(description),
      buffTarget: /physical.{0,18}attack/.test(description) ? "Physical" : /special attack/.test(description) ? "Special" : "",
      area: /orbit|aura|burst|spin|melee|shove|vortex|quake|spray|cone|nova/.test(kind) || /around you|in every direction|nearby/.test(description),
      targeted: /projectile|homing|chain|bounce|turret|beam|charge|dash|boomerang|meteor|mine|trail/.test(kind),
      control: /slow|freeze|stun|paraly|push|knock|pull|trap|snare|drag/.test(description),
      sustain: /heal|heals|healing|regeneration|regen/.test(description),
      statuses
    };
  }

  function getMoveData(name) {
    return moveData.find((move) => normalize(move.name) === normalize(name)) || null;
  }

  function synergyScore(move) {
    const learned = state.learnedMoves.map((item) => getMoveData(item.name)).filter(Boolean);
    if (!learned.length) return { score: 0, reasons: [] };
    const profile = moveProfile(move);
    const learnedProfiles = learned.map((item) => ({ move: item, profile: moveProfile(item) }));
    const reasons = [];
    let score = 0;

    if (profile.isBuff && profile.buffTarget) {
      const matching = learnedProfiles.filter((item) => item.profile.category === profile.buffTarget).length;
      if (matching) {
        score += Math.min(18, 10 + matching * 4);
        reasons.push(`buff hỗ trợ ${matching} move ${profile.buffTarget === "Physical" ? "vật lý" : "đặc biệt"}`);
      }
    }
    if (profile.category) {
      const supported = learnedProfiles.some((item) => item.profile.isBuff && item.profile.buffTarget === profile.category);
      if (supported) {
        score += 10;
        reasons.push(`ăn khớp buff ${profile.category === "Physical" ? "vật lý" : "đặc biệt"} đã học`);
      }
    }
    if (profile.control && learnedProfiles.some((item) => !item.profile.isBuff && !item.profile.control)) {
      score += 6;
      reasons.push("bổ sung khống chế cho nhóm gây sát thương đang có");
    }
    if (profile.area && learnedProfiles.some((item) => item.profile.targeted && !item.profile.isBuff)) {
      score += 5;
      reasons.push("bù vùng đánh cho move nhắm mục tiêu");
    }
    if (profile.targeted && learnedProfiles.some((item) => item.profile.area && !item.profile.isBuff)) {
      score += 5;
      reasons.push("bù khả năng đánh mục tiêu cho move diện rộng");
    }
    if (profile.sustain && learnedProfiles.some((item) => !item.profile.isBuff)) {
      score += state.strategy === "survival" ? 9 : 4;
      reasons.push("ghép hồi phục với nhóm gây sát thương");
    }

    const description = normalize(move.description);
    if (/more damage if they are burned poisoned or slowed/.test(description)) {
      const statusReady = learnedProfiles.some((item) => item.profile.statuses.some((status) => ["burn", "poison", "slow"].includes(status)));
      if (statusReady) {
        score += 18;
        reasons.push("kích hoạt điều kiện gây thêm sát thương của Hex");
      }
    }
    return { score: Math.min(score, 30), reasons };
  }

  function scoreCandidate(candidate) {
    let score = 0;
    const reasons = [];
    const pokemon = currentPokemon();
    const learned = state.learnedMoves.find((item) => candidate.move && normalize(item.name) === normalize(candidate.move.name));
    const strategy = state.strategy;

    if (candidate.evolution) {
      score += 100;
      reasons.push("thẻ tiến hóa vàng đã mở");
    }

    if (candidate.move) {
      const move = candidate.move;
      if (state.targets.some((target) => normalize(target) === normalize(move.name))) {
        score += 38;
        reasons.push("đúng skill mục tiêu");
      }
      const monoTypeMatch = pokemon?.types.length === 1 && normalize(pokemon.types[0]) === normalize(move.type);
      if (monoTypeMatch) {
        score += 15;
        reasons.push(`đúng hệ đơn ${move.type} (+20% sát thương trong game)`);
      }
      if (strategy === "physical" && move.category === "Physical") {
        score += 12;
        reasons.push("khớp hướng vật lý");
      }
      if (strategy === "special" && move.category === "Special") {
        score += 12;
        reasons.push("khớp hướng đặc biệt");
      }
      if (learned) {
        score += 16;
        reasons.push(`nâng move đang có (${learned.level || 1}/5)`);
      } else if (!state.learnedMoves.length) {
        score += 15;
        reasons.push("mở bộ skill đầu lượt");
      } else if (state.learnedMoves.length < 2) {
        score += 7;
        reasons.push("mở rộng bộ move đầu lượt");
      }
      const synergy = synergyScore(move);
      score += synergy.score;
      reasons.push(...synergy.reasons);
      const profile = moveProfile(move);
      if (strategy === "survival" && (profile.sustain || profile.control || /armor|defen|heal/i.test(`${move.description} ${move.kind}`))) {
        score += 9;
        reasons.push("có khống chế hoặc hỗ trợ sinh tồn");
      }
      if (strategy === "evolve" && move.evoStat) {
        score += 3;
        reasons.push(`có công thức tiến hóa với ${move.evoStat}`);
      }
    }

    if (candidate.stat) {
      const recipes = moveData.filter((move) => move.evoStat && state.learnedMoves.some((item) => normalize(item.name) === normalize(move.name) && !item.evolved) && normalize(move.evoStat) === normalize(candidate.stat));
      const targetRecipes = moveData.filter((move) => move.evoStat && state.targets.some((target) => normalize(target) === normalize(move.name)) && normalize(move.evoStat) === normalize(candidate.stat));
      if (recipes.length) {
        const closest = Math.max(...recipes.map((move) => state.learnedMoves.find((item) => normalize(item.name) === normalize(move.name))?.level || 1));
        score += closest >= 5 ? 34 : closest >= 4 ? 27 : closest >= 3 ? 19 : 10;
        const nearlyReady = recipes.filter((move) => (state.learnedMoves.find((item) => normalize(item.name) === normalize(move.name))?.level || 1) >= 5);
        reasons.push(nearlyReady.length
          ? `đúng stat tiến hóa cho ${nearlyReady.map((move) => move.name).slice(0, 2).join(", ")} Lv 5`
          : `đang chuẩn bị tiến hóa cho ${recipes.map((move) => move.name).slice(0, 2).join(", ")}`);
      }
      if (targetRecipes.length) {
        score += 20;
        reasons.push(`cần cho skill mục tiêu ${targetRecipes[0].name}`);
      }
      if (strategy === "evolve" && (recipes.length || targetRecipes.length)) score += 10;
      if (strategy === "survival" && ["Armor", "Synthesis", "Vigor"].includes(candidate.stat)) {
        score += 9;
        reasons.push("hợp hướng tăng khả năng trụ lại");
      }
      const statCount = state.statPicks.filter((item) => normalize(item) === normalize(candidate.stat)).length;
      if (statCount >= 2 && !recipes.length && !targetRecipes.length) score -= 5;
    }

    if (!candidate.move && !candidate.stat && !candidate.evolution) {
      if (/heal|regen|shield|armor|health|hp|revive|defen/i.test(candidate.normalizedText)) {
        score += strategy === "survival" ? 16 : 6;
        reasons.push("hiệu ứng phòng thủ hoặc hồi phục");
      }
      if (/damage|attack|power|cooldown|projectile|speed/i.test(candidate.normalizedText) && ["balanced", "physical", "special", "evolve"].includes(strategy)) {
        score += 4;
        reasons.push("tăng sức mạnh tổng quát");
      }
    }

    if (!reasons.length) reasons.push("chưa khớp dữ liệu move; cân nhắc theo tình trạng run");
    return { ...candidate, score, reasons };
  }

  function refreshRecommendations() {
    const candidates = cardNodes().map(candidateFromCard).filter((candidate) => candidate.text);
    cachedCandidates = candidates.map(scoreCandidate).sort((a, b) => b.score - a.score);
    const hasClearRecommendation = (cachedCandidates[0]?.score || 0) > 0;
    cardNodes().forEach((card) => {
      card.removeAttribute("data-psba-rank");
      card.removeAttribute("data-psba-label");
    });
    if (hasClearRecommendation) cachedCandidates.forEach((candidate, index) => {
      if (index < 3) {
        candidate.element.setAttribute("data-psba-rank", String(index + 1));
        candidate.element.setAttribute("data-psba-label", `#${index + 1}`);
      }
    });
    renderRecommendations(cachedCandidates, hasClearRecommendation);
    const level = document.querySelector("#lvl-num")?.textContent?.trim();
    ui.level.textContent = isLevelUpVisible ? `Level ${level || "?"}` : "chờ thẻ";
    scheduleAutoPick(cachedCandidates, hasClearRecommendation);
  }

  function cardSelectionSignature() {
    const level = document.querySelector("#lvl-num")?.textContent?.trim() || "?";
    const text = cardNodes().map((card) => normalize(card.innerText || card.textContent || "")).join("||");
    return `${level}:${text}`;
  }

  function scoredCandidateSignature(candidates) {
    const scores = candidates.map((candidate) => `${normalize(candidate.text)}=${candidate.score}:${normalize(candidate.reasons.join(" "))}`).join("||");
    return `${cardSelectionSignature()}::${scores}`;
  }

  function scheduleAutoPick(candidates, hasClearRecommendation) {
    const cardSignature = cardSelectionSignature();
    const planSignature = scoredCandidateSignature(candidates);
    if (!state.autoPick || !isLevelUpVisible) {
      if (autoPickTimer) clearTimeout(autoPickTimer);
      autoPickTimer = null;
      pendingAutoPickSignature = "";
      ui.autoStatus.textContent = state.autoPick ? "Đang chờ thẻ lên cấp." : "Tự chọn đang tắt; extension vẫn xếp hạng và theo dõi lựa chọn.";
      return;
    }
    if (autoPickTimer && pendingAutoPickSignature === planSignature) return;
    if (autoPickTimer) clearTimeout(autoPickTimer);
    autoPickTimer = null;
    pendingAutoPickSignature = "";
    if (!candidates.length) {
      ui.autoStatus.textContent = "Đang chờ nội dung thẻ lên cấp.";
      return;
    }
    if (autoPickSignature === cardSignature) {
      ui.autoStatus.textContent = "Đã ghi nhận lựa chọn ở cấp này.";
      return;
    }

    const best = candidates[0];
    const runnerUp = candidates[1];
    const gap = best ? best.score - (runnerUp?.score ?? 0) : 0;
    const confident = hasClearRecommendation && best?.score > AUTO_PICK_MIN_SCORE && (!runnerUp || gap > 0);
    if (!confident) {
      ui.autoStatus.textContent = `Đang chờ thẻ đạt trên 6 điểm và dẫn đầu${best ? ` (hiện dẫn ${Math.max(0, gap)} điểm)` : ""}; bạn có thể chọn thủ công.`;
      return;
    }

    ui.autoStatus.textContent = `Sẽ tự chọn ${best.move?.name || best.text.slice(0, 32)} sau khi thẻ ổn định.`;
    pendingAutoPickSignature = planSignature;
    autoPickTimer = setTimeout(() => {
      autoPickTimer = null;
      pendingAutoPickSignature = "";
      const currentScreen = document.querySelector("#scr-levelup");
      const currentCandidates = cardNodes().map(candidateFromCard).filter((candidate) => candidate.text).map(scoreCandidate).sort((a, b) => b.score - a.score);
      if (!state.autoPick || !isLevelUpVisible || !currentScreen || currentScreen.classList.contains("hidden") || getComputedStyle(currentScreen).display === "none" || scoredCandidateSignature(currentCandidates) !== planSignature || !best.element.isConnected) return;
      best.element.click();
      const stillVisible = !currentScreen.classList.contains("hidden") && getComputedStyle(currentScreen).display !== "none";
      const accepted = !stillVisible || cardsRoot.classList.contains("done");
      if (!accepted) {
        autoPickSignature = "";
        ui.autoStatus.textContent = "Game chưa nhận click nên skill chưa được ghi nhận; bạn có thể chọn thẻ thủ công.";
        return;
      }
      autoPickSignature = cardSignature;
      trackGameSelection(best);
      ui.autoStatus.textContent = `Đã bấm và ghi nhận: ${best.move?.name || best.text.slice(0, 32)}.`;
      ui.status.textContent = `Game đã nhận thẻ phù hợp nhất cho ${state.pokemon || "Pokémon hiện tại"}.`;
    }, AUTO_PICK_DELAY_MS);
  }

  function fusionPairScore(moveA, moveB) {
    const profileA = moveProfile(moveA);
    const profileB = moveProfile(moveB);
    let score = 0;
    const reasons = [];
    const attackingA = !profileA.isBuff;
    const attackingB = !profileB.isBuff;
    if (profileA.category && profileA.category === profileB.category) {
      score += 7;
      reasons.push(`cùng tận dụng chỉ số ${profileA.category === "Physical" ? "vật lý" : "đặc biệt"}`);
    }
    const buffPair = profileA.isBuff ? [profileA, profileB] : profileB.isBuff ? [profileB, profileA] : null;
    if (buffPair?.[0].buffTarget && buffPair[0].buffTarget === buffPair[1].category) {
      score += 16;
      reasons.push("buff khớp đòn tấn công trong cùng nhóm");
    }
    if (attackingA && attackingB && profileA.area !== profileB.area) {
      score += 8;
      reasons.push("cân bằng diện rộng và nhắm mục tiêu");
    }
    if ((profileA.control && attackingB) || (profileB.control && attackingA)) {
      score += 7;
      reasons.push("khống chế hỗ trợ move gây sát thương");
    }
    const hex = normalize(moveA.name) === "hex" ? moveA : normalize(moveB.name) === "hex" ? moveB : null;
    const other = hex === moveA ? moveB : moveA;
    if (hex && moveProfile(other).statuses.some((status) => ["burn", "poison", "slow"].includes(status))) {
      score += 18;
      reasons.push("kích hoạt thêm sát thương của Hex");
    }
    if ((profileA.sustain && attackingB) || (profileB.sustain && attackingA)) {
      score += 5;
      reasons.push("hồi phục đi cùng sát thương");
    }
    const pokemon = currentPokemon();
    if (pokemon?.types.length === 1 && normalize(pokemon.types[0]) === normalize(moveA.type) && normalize(moveA.type) === normalize(moveB.type)) {
      score += 6;
      reasons.push(`cùng hệ đơn ${moveA.type}`);
    }
    if (profileA.isBuff && profileB.isBuff) {
      score -= 8;
      reasons.push("cặp này thiếu đòn gây sát thương trực tiếp");
    }
    return { score, reasons: reasons.slice(0, 3) };
  }

  function markMovesFused(names) {
    const normalizedNames = names.map(normalize);
    const involved = state.fusedGroups.filter((group) => group.some((name) => normalizedNames.includes(normalize(name))));
    if (involved.length > 1) {
      ui.autoStatus.textContent = "Game chỉ cho thêm skill lẻ vào một nhóm Bond đang mở.";
      return;
    }
    const merged = [...new Set([...involved.flat(), ...names].map((name) => moveData.find((move) => normalize(move.name) === normalize(name))?.name || name))];
    if (merged.length > MAX_MOVE_SLOTS) {
      ui.autoStatus.textContent = "Một nhóm Bond tối đa 4 skill.";
      return;
    }
    state.fusedGroups = state.fusedGroups.filter((group) => !involved.includes(group));
    state.fusedGroups.push(merged);
    persistState();
    renderBuild();
  }

  function renderFusionSuggestions() {
    ui.fusions.replaceChildren();
    const moves = state.learnedMoves.map((item) => getMoveData(item.name)).filter(Boolean);
    const fusionCount = state.fusedGroups.reduce((total, group) => total + Math.max(0, group.length - 1), 0);
    ui.bondCount.textContent = state.fusedGroups.length ? `${fusionCount} Bond đã ghi` : `${moves.length} skill`;
    if (moves.length < 2) {
      const message = document.createElement("p");
      message.className = "muted";
      message.textContent = "Học thêm skill để xem các cặp kết hợp.";
      ui.fusions.append(message);
      return;
    }
    const groupedNames = new Set(state.fusedGroups.flat().map(normalize));
    const loose = moves.filter((move) => !groupedNames.has(normalize(move.name)));
    const growingGroup = state.fusedGroups.find((group) => group.length > 1 && group.length < MAX_MOVE_SLOTS);
    const options = [];
    if (growingGroup && loose.length) {
      const groupMoves = growingGroup.map(getMoveData).filter(Boolean);
      for (const add of loose) {
        const matches = groupMoves.map((move) => fusionPairScore(move, add));
        options.push({ group: [...growingGroup], add, score: Math.round(matches.reduce((sum, item) => sum + item.score, 0) / matches.length), reasons: [...new Set(matches.flatMap((item) => item.reasons))].slice(0, 3) });
      }
    } else if (!growingGroup) {
      for (let i = 0; i < loose.length; i += 1) {
        for (let j = i + 1; j < loose.length; j += 1) {
          const result = fusionPairScore(loose[i], loose[j]);
          options.push({ group: [loose[i].name], add: loose[j], ...result });
        }
      }
    }
    options.sort((a, b) => b.score - a.score);
    if (!options.length) {
      const message = document.createElement("p");
      message.className = "muted";
      message.textContent = growingGroup
        ? "Nhóm Bond đang chờ một skill lẻ để ghép thêm."
        : loose.length < 2
          ? "Cần hai skill chưa ghép để dùng Bond tiếp theo."
          : "Các skill đã được đánh dấu trong nhóm Bond.";
      ui.fusions.append(message);
      return;
    }
    for (const option of options.slice(0, 3)) {
      const row = document.createElement("div");
      row.className = "recommendation";
      const title = document.createElement("div");
      title.className = "recommendation-head";
      const names = document.createElement("strong");
      names.textContent = `${option.group.join(" + ")} + ${option.add.name}`;
      const score = document.createElement("span");
      score.className = "score";
      score.textContent = `${option.score}đ`;
      title.append(names, score);
      const reason = document.createElement("p");
      reason.textContent = option.reasons.join(" · ") || "Các move trong nhóm cùng kích hoạt khi ghép Bond.";
      const mark = document.createElement("button");
      mark.type = "button";
      mark.className = "text-button fusion-mark";
      mark.textContent = "Đánh dấu đã ghép";
      mark.addEventListener("click", () => markMovesFused([...option.group, option.add.name]));
      row.append(title, reason, mark);
      ui.fusions.append(row);
    }
  }

  function renderRecommendations(candidates, hasClearRecommendation) {
    ui.recommendations.replaceChildren();
    if (!isLevelUpVisible || !candidates.length) {
      const message = document.createElement("p");
      message.className = "muted";
      message.textContent = isLevelUpVisible ? "Chưa đọc được nội dung thẻ. Gợi ý sẽ hiện khi game cập nhật danh sách." : "Khi màn hình chọn thẻ xuất hiện, gợi ý sẽ hiện ở đây.";
      ui.recommendations.append(message);
      return;
    }
    if (!hasClearRecommendation) {
      const message = document.createElement("p");
      message.className = "muted";
      message.textContent = "Các thẻ chưa khớp đủ dữ liệu để xếp hạng đáng tin cậy. Hãy cân nhắc theo tình trạng run hoặc kiểm tra lại Pokémon/build.";
      ui.recommendations.append(message);
      for (const candidate of candidates) {
        const fallback = document.createElement("div");
        fallback.className = "recommendation";
        fallback.textContent = candidate.text.slice(0, 90) || "Lựa chọn chưa nhận diện";
        ui.recommendations.append(fallback);
      }
      return;
    }
    for (const [index, candidate] of candidates.slice(0, 3).entries()) {
      const row = document.createElement("div");
      row.className = `recommendation ${index === 0 ? "best" : ""}`;
      const title = document.createElement("div");
      title.className = "recommendation-head";
      const name = document.createElement("strong");
      name.textContent = candidate.move?.name || candidate.text.slice(0, 76) || "Lựa chọn";
      const score = document.createElement("span");
      score.className = "score";
      score.textContent = `${candidate.score}đ`;
      title.append(name, score);
      const reason = document.createElement("p");
      reason.textContent = candidate.reasons.slice(0, 3).join(" · ");
      row.append(title, reason);
      ui.recommendations.append(row);
    }
  }

  function onGameCardClick(event) {
    const target = event.target instanceof Element ? event.target : null;
    const card = target?.closest("#cards .card") || target?.closest('#cards button, #cards [role="button"]') || target?.closest("#cards > *");
    if (!card || !event.isTrusted) return;
    stopAutoPickForManualChoice();
    trackGameSelection(candidateFromCard(card));
  }

  function onGameLevelUpKeydown(event) {
    if (!isLevelUpVisible || event.defaultPrevented || event.repeat || event.altKey || event.ctrlKey || event.metaKey) return;
    if (event.composedPath().includes(host)) return;
    const target = event.target;
    if (target instanceof Element && target.closest("input, textarea, select, [contenteditable='true']")) return;
    const index = { "1": 0, "2": 1, "3": 2 }[event.key];
    if (index === undefined) return;
    const card = cardNodes()[index];
    if (!card) return;
    if (event.isTrusted) stopAutoPickForManualChoice();
    trackGameSelection(candidateFromCard(card));
  }

  function stopAutoPickForManualChoice() {
    if (autoPickTimer) clearTimeout(autoPickTimer);
    autoPickTimer = null;
    pendingAutoPickSignature = "";
    autoPickSignature = cardSelectionSignature();
  }

  function trackGameSelection(candidate) {
    const signature = cardSelectionSignature();
    const now = Date.now();
    if (signature === lastTrackedSelectionSignature && now - lastTrackedSelectionAt < 800) return;
    lastTrackedSelectionSignature = signature;
    lastTrackedSelectionAt = now;
    if (candidate.evolution) {
      const matched = state.learnedMoves.find((move) => candidate.normalizedText.includes(normalize(move.name)));
      if (matched) matched.evolved = true;
    } else if (candidate.move) {
      const existing = state.learnedMoves.find((move) => normalize(move.name) === normalize(candidate.move.name));
      if (existing) existing.level = Math.min(5, Number(existing.level || 1) + 1);
      else if (state.learnedMoves.length < MAX_MOVES_WITH_BONDS) state.learnedMoves.push({ name: candidate.move.name, level: 1, evolved: false });
    } else if (candidate.stat) {
      state.statPicks.push(candidate.stat);
      state.statPicks = state.statPicks.slice(-12);
    }
    persistState();
    renderBuild();
    refreshRecommendations();
  }

  function renderBuild() {
    ui.build.replaceChildren();
    if (!state.learnedMoves.length && !state.statPicks.length) {
      const empty = document.createElement("p");
      empty.className = "muted";
      empty.textContent = "Chưa ghi nhận lựa chọn nào.";
      ui.build.append(empty);
      renderFusionSuggestions();
      return;
    }
    for (const move of state.learnedMoves) {
      const row = document.createElement("div");
      row.className = "build-item";
      const name = document.createElement("span");
      name.textContent = move.name;
      const level = document.createElement("span");
      level.className = "build-level";
      level.textContent = move.evolved ? "Đã tiến hóa" : `Lv ${move.level || 1}/5`;
      row.append(name, level);
      ui.build.append(row);
    }
    if (state.statPicks.length) {
      const stats = document.createElement("p");
      stats.className = "muted stat-history";
      stats.textContent = `Stat gần đây: ${state.statPicks.slice(-5).join(", ")}`;
      ui.build.append(stats);
    }
    for (const group of state.fusedGroups) {
      const fusion = document.createElement("p");
      fusion.className = "muted stat-history";
      fusion.textContent = `Bond: ${group.join(" + ")}`;
      ui.build.append(fusion);
    }
    renderFusionSuggestions();
  }

  function setPanelOpen(open) {
    panelOpen = Boolean(open);
    ui.panel.classList.toggle("open", panelOpen);
    ui.fab.classList.toggle("visible", !panelOpen);
  }

  const PANEL_CSS = `
    :host { all: initial; color-scheme: dark; font-family: system-ui, -apple-system, Segoe UI, sans-serif; }
    * { box-sizing: border-box; }
    .panel { position: fixed; z-index: 2147483646; top: 14px; right: 14px; width: min(318px, calc(100vw - 24px)); max-height: min(78vh, 720px); overflow: hidden; display: none; color: #eef4ff; background: #101827; border: 1px solid #394760; border-radius: 14px; box-shadow: 0 16px 48px #0009; font-size: 13px; }
    .panel.open { display: flex; flex-direction: column; }
    .header { display: flex; align-items: center; justify-content: space-between; padding: 12px 14px; background: linear-gradient(120deg, #1d2a40, #172031); border-bottom: 1px solid #394760; }
    .header strong { display: block; font-size: 16px; letter-spacing: .1px; }
    .eyebrow { color: #f5c76b; font-size: 9px; font-weight: 800; letter-spacing: 1.4px; margin-bottom: 2px; }
    .icon-button, .quiet-button, .text-button, .chip { font: inherit; cursor: pointer; }
    .icon-button { width: 28px; height: 28px; border: 1px solid #53617a; border-radius: 8px; background: #27364b; color: white; font-size: 18px; line-height: 1; }
    .body { overflow: auto; padding: 12px; }
    .status { margin: 0 0 12px; color: #9fb1cc; font-size: 11px; line-height: 1.45; }
    label, .section-title { display: flex; align-items: center; justify-content: space-between; margin: 10px 0 6px; font-size: 11px; font-weight: 750; color: #c9d6e9; }
    input, select { width: 100%; min-width: 0; height: 34px; border: 1px solid #45556f; border-radius: 8px; padding: 0 9px; color: #eef4ff; background: #172235; font: inherit; outline: none; }
    input:focus, select:focus { border-color: #f5c76b; box-shadow: 0 0 0 2px #f5c76b30; }
    .pokemon-row, .target-row { display: flex; gap: 6px; }
    .owned-row { display: flex; gap: 5px; margin-top: 7px; }
    .owned-row input:first-child { flex: 1 1 auto; width: 100%; }
    .owned-row .known-level-input { flex: 0 0 45px; width: 45px; padding: 0 5px; }
    .quiet-button { flex: 0 0 auto; border: 1px solid #52617a; border-radius: 8px; background: #25334a; color: #e9f1ff; padding: 0 9px; }
    .types { min-height: 26px; display: flex; align-items: center; gap: 6px; margin: 5px 0 8px; }
    .type-pill { border-radius: 999px; background: #31415c; color: #dceaff; padding: 3px 8px; font-size: 10px; font-weight: 700; }
    .muted, .section-title small { color: #9baac0; font-size: 11px; }
    .auto-pick-row { justify-content: flex-start; margin: 9px 0 2px; cursor: pointer; }
    .auto-pick-row span { display: flex; align-items: center; gap: 8px; }
    .auto-pick-row input { width: 15px; height: 15px; margin: 0; padding: 0; accent-color: #f5c76b; }
    .auto-status { margin: 0 0 6px; font-size: 10px; line-height: 1.35; }
    .section-title { margin-top: 13px; }
    .section-title small { font-weight: 500; }
    .text-button { border: 0; color: #f1c66b; background: transparent; padding: 0; font-size: 10px; }
    .chips { display: flex; flex-wrap: wrap; gap: 5px; margin-top: 6px; }
    .chips.empty { display: block; color: #8e9db3; font-size: 11px; }
    .chip { border: 1px solid #53617a; border-radius: 999px; background: #25334a; color: #e9f1ff; padding: 4px 8px; font-size: 10px; }
    .recommendations, .build-list { display: grid; gap: 6px; }
    .recommendation { padding: 8px 9px; border: 1px solid #394760; border-radius: 9px; background: #172235; }
    .recommendation.best { border-color: #c49b45; background: #2a281f; }
    .recommendation-head { display: flex; gap: 8px; justify-content: space-between; align-items: flex-start; }
    .recommendation-head strong { font-size: 12px; line-height: 1.3; }
    .score { flex: 0 0 auto; color: #f5c76b; font-size: 10px; font-weight: 800; }
    .recommendation p { margin: 4px 0 0; color: #aebbd0; font-size: 10px; line-height: 1.35; }
    .fusion-mark { display: block; margin: 5px 0 0 auto; }
    .build-item { display: flex; justify-content: space-between; gap: 8px; padding: 5px 7px; background: #172235; border-radius: 7px; font-size: 11px; }
    .build-level { color: #b8c9e1; white-space: nowrap; }
    .stat-history { margin: 3px 0 0; }
    .footnote { margin: 12px 0 0; padding-top: 9px; border-top: 1px solid #344157; color: #8796ad; font-size: 10px; line-height: 1.4; }
    .fab { position: fixed; z-index: 2147483646; right: 14px; bottom: 16px; display: none; width: 42px; height: 42px; border: 2px solid #f5c76b; border-radius: 50%; background: #152137; color: #f5c76b; font-weight: 900; box-shadow: 0 5px 18px #0008; cursor: pointer; }
    .fab.visible { display: block; }
    @media (max-width: 700px) { .panel { top: auto; bottom: 10px; right: 10px; width: min(320px, calc(100vw - 20px)); max-height: 55vh; } .fab { right: 10px; bottom: 10px; } }
  `;
  const panelStyle = document.createElement("style");
  panelStyle.textContent = PANEL_CSS;
  shadow.prepend(panelStyle);
})();
