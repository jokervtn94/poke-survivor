# PokéSurvivor Build Assistant 0.3.2

Chrome/Edge Manifest V3 extension for **pokesurvivor.com**. It tracks the current run, scores level-up cards against the Pokémon and moves already learned, suggests move combinations for Bonds, and can select the leading card automatically when the score is clearly ahead.

## Install for local use

1. Download and unzip this package.
2. Open `chrome://extensions` in Chrome or `edge://extensions` in Edge.
3. Turn on **Developer mode**.
4. Choose **Load unpacked** and select this folder.
5. Open or refresh `https://pokesurvivor.com/`.

The extension fetches and caches the public Pokédex and move reference pages from the same site for 24 hours. Its only persistent data is the Pokémon/build preferences and the cached reference HTML in extension storage.

## How suggestions work

- The extension looks for the live partner name in the game's menu DOM, with a manual Pokémon search as a fallback.
- At level-up, it reads the text and data attributes from the game cards under `#cards`, ranks them, and marks the top three. It also recognizes the game's `1`–`3` level-up keys so the tracker stays current when you use the keyboard.
- It prioritizes a ready evolution, chosen target moves, stat cards for tracked evolution recipes, and move choices that complement skills already learned. Physical/special buffs support matching damage moves; the planner also looks for control, area coverage, healing and the status condition used by Hex.
- Card choices are tracked automatically by click or the game's `1`–`3` keys. Add the starting move or any move already owned in the small field under the run tracker, with its current level, so synergy and evolution advice includes it.
- **Tự chọn thẻ dẫn điểm** is on by default. The extension clicks the best card after 750 ms when its score is over 6 and it strictly leads the next card, giving the game's card lock time to expire. Tied scores stay manual. It records the move only after the game accepts the choice. Turn the option off in the panel to return to recommendation-only mode.
- The run tracker supports up to 16 moves across four game slots. After using a Bond, click **Đánh dấu đã ghép** on the suggested pair so the extension can update the group and avoid suggesting that pair again. A bonded group can contain up to four moves.
- When the game shows its `#scr-over` screen ("You fell…"), the extension clears the current run's learned moves, stat picks, and level counter. It keeps the Pokémon, build style, and target moves for the next run.

The recommendation score is a transparent heuristic. It does not inspect live health, enemies, weather, or hidden game state. The player chooses which move to activate in battle; Bond suggestions estimate useful combinations from move descriptions and do not represent special recipes. A localized card name may not match the English reference catalog, in which case the card remains unranked or gets a lower-confidence score.

## Notes

- The game uses a canvas for the arena and a DOM region for level-up cards. The extension hooks the observed `#scr-levelup` / `#cards` structure and may need a small selector update if the game changes its UI.
- The game and Pokémon content remain the property of their respective owners. This is an unofficial companion project and is not affiliated with PokéSurvivor, Nintendo, GAME FREAK, or The Pokémon Company.
- The PokéSurvivor site identifies its current code license as PolyForm Noncommercial 1.0.0; this extension does not bundle or modify the game's source code, sprites, or music.

## References

- https://pokesurvivor.com/en/guide/
- https://pokesurvivor.com/en/pokedex/
- https://pokesurvivor.com/en/moves/
- https://github.com/JPTER78/pokesurvivor
